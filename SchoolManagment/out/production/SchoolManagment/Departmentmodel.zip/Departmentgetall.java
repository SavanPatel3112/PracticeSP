public class Departmentgetall extends Departmentmodel{
    private int size;
    int i;
    Departmentmodel[] departmentmodels;

    public Departmentgetall(int b, int departmentId, String departmentName, String departmentDesc) {
        super(b, departmentId, departmentName, departmentDesc);
    }

    public void setDeparmentSize(int n){
        departmentmodels = new Departmentmodel[n];
    }
    void adddepartment(Department department,int n){
        Department[] Department = new Department[n];
        Department[i] = department;
    }
    public Departmentmodel[] getAllDepartment(){
        return departmentmodels;
    }
}
