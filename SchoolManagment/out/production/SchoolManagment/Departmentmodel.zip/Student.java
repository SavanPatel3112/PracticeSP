import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Student{
    int b=0;
    int s;
    Scanner sc = new Scanner(System.in);



    public void method2(HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap){
        System.out.println("Enter the department id where you want student add: ");
        int departmentId = sc.nextInt();sc.nextLine();

        Departmentmodel departmentmodel=new Departmentmodel();
        if (!dmmodel.isEmpty()){
            for (Map.Entry<Integer,Departmentmodel> departmentmodel1 : dmmodel.entrySet()){
                if (departmentmodel1.getValue().getId()!=0 && departmentmodel1.getValue().getId() == departmentId){
                    departmentmodel = departmentmodel1.getValue();
                    break;
                }
                else {
                    System.out.println("Not match the department id");
                }
            }

        }

        System.out.println("-----------StudentDetails-----------\n1)Add\n2)View\n3)Delete\n4)Update\n5)Exit");
        System.out.println("Select option");
        s = sc.nextInt();
        switch (s) {
            case 1 -> {
                smmap = Add(dmmodel, smmap,departmentmodel);
                method2(dmmodel, smmap);
            }
            case 2 -> {
                smmap = View(dmmodel, smmap);
                method2(dmmodel, smmap);
            }
            case 3 -> {
                smmap = Delete(dmmodel, smmap);
                method2(dmmodel, smmap);
            }
            case 4 -> {
                smmap = Update(dmmodel,smmap);
                method2(dmmodel,smmap);
            }
            default -> {
            }
        }
    }

    public HashMap<Integer,Studentmodel> Add(HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap,Departmentmodel departmentmodel){
        Studentmodel studentmodel = null;

        System.out.println("Enter the student id: ");
        int studentId = sc.nextInt();sc.nextLine();

        System.out.println("Enter the student name: ");
        String studentName = sc.nextLine();

        System.out.println("Enter the student number: ");
        int studentNumber = sc.nextInt();sc.nextLine();

        System.out.println("Enter the student address: ");
        String studentAddress = sc.nextLine();

        System.out.println("Enter the student grade: ");
        String studentGrade = sc.nextLine();

        Studentmodel sm = new Studentmodel(studentId,studentName,studentNumber,studentAddress,studentGrade,departmentmodel.getId());
        smmap.put(b,sm);
        b++;

        System.out.println("You want add more Yes/No");
        String check = sc.next();
        if (check.equalsIgnoreCase("Yes")){
            smmap = Add(dmmodel,smmap,departmentmodel);
        }
        return smmap;
    }

    public HashMap<Integer,Studentmodel> View (HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap){
        for (Map.Entry<Integer,Studentmodel> obj:smmap.entrySet()){
            System.out.println("-----------All Student-----------");
            System.out.println("Id:-> "+obj.getValue().getStudentId()+"\n"+"Name:-> "+obj.getValue().getStudentName()+"\n"+"Number:-> "+obj.getValue().getStudentNumber()+"\n"+"Address:-> "+obj.getValue().getStudentAddress()+"\n"+"Grade:-> "+obj.getValue().getStudentGrade());
        }
        return smmap;
    }
    public HashMap<Integer,Studentmodel> Delete (HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap){
        System.out.println("Enter the id you want to delete: ");
        int de =sc.nextInt();
        for (Map.Entry<Integer,Studentmodel> obj:smmap.entrySet()){
            if (de == obj.getKey()){
                smmap.remove(de);
                break;
            }
        }
        return smmap;
    }
    public HashMap<Integer,Studentmodel> Update (HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap){
        int a = sc.nextInt();
        for (Map.Entry<Integer,Studentmodel>obj : smmap.entrySet()){
            if (a == obj.getValue().getStudentId()){
                System.out.println("What do you want change in department: ");
                System.out.println("1)StudentName\n2)Number\n3)Address\n4)Grade");
                System.out.println("Enter your choice: ");
                int update = sc.nextInt();
                if (update==1){
                    System.out.println("Enter the Student new name:  ");
                    String studentName = sc.next();
                    obj.getValue().setStudentName(studentName);
                }else if (update==2){
                    System.out.println("Enter the student new number: ");
                    int studentNumber = sc.nextInt();
                    obj.getValue().setStudentNumber(studentNumber);
                }else if(update==3){
                    System.out.println("Enter the student new address: ");
                    String studentAddress = sc.next();
                    obj.getValue().setStudentAddress(studentAddress);
                }else if (update==4){
                    System.out.println("Enter the student new grade: ");
                    String studentGrade = sc.next();
                    obj.getValue().setStudentGrade(studentGrade);
                }
                break;
            }
        }
        return smmap;
    }
}











































