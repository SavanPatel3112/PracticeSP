import java.util.*;

public class Department {
    int a;
    int b = 0;
    Scanner sc = new Scanner(System.in);
    public void method1(HashMap<Integer,Departmentmodel>dmmodel,HashMap<Integer,Studentmodel>smmap){
        System.out.println("-----------DepartmenttDetails-----------\n1)Add\n2)View\n3)Delete\n4)Update\n5)Exit");
        System.out.println("Select option");
        a=sc.nextInt();sc.nextLine();

        switch (a) {
            case 1 -> dmmodel = Add(dmmodel);
            case 2 -> dmmodel = View(dmmodel);
            case 3 -> dmmodel = Delete(dmmodel);
            case 4 -> dmmodel = Update(dmmodel);
            case 5 -> new Alltask().run(dmmodel, smmap);
            default -> {
            }
        }
        method1(dmmodel,smmap);
    }
    public HashMap<Integer,Departmentmodel> Add (HashMap<Integer,Departmentmodel>dmmap){
        System.out.println("Enter the department id: ");
        int departmentId = sc.nextInt();sc.nextLine();

        System.out.println("Enter the department name: ");
        String departmentName =sc.next();

        System.out.println("Enter the department description: ");
        String departmentDescription = sc.next();

        Departmentmodel dm = new Departmentmodel(b,departmentId,departmentName,departmentDescription);
        dmmap.put(b,dm);
        b++;
        System.out.println("You Want add more department?Yes/No");
        String check = sc.next();
        if (check.equalsIgnoreCase("yes")){
            dmmap = Add(dmmap);
        }
        return dmmap;
    }
    public HashMap<Integer,Departmentmodel> View (HashMap<Integer,Departmentmodel>dmmap){
        for (Map.Entry<Integer,Departmentmodel> obj:dmmap.entrySet()){
            System.out.println("-----------All Department-----------");
            System.out.println("Id:-> "+obj.getValue().getId()+"\n"+"Name:-> "+obj.getValue().getDepartmentName()+"\n"+"Description:-> "+obj.getValue().getDepartmentDesc());
        }
        return dmmap;
    }
    public HashMap<Integer,Departmentmodel> Delete (HashMap<Integer,Departmentmodel>dmmap){
        System.out.println("Enter id number ypu want to delete: ");
        int d =sc.nextInt();
        for (Map.Entry<Integer,Departmentmodel>obj:dmmap.entrySet()){
            if (d==obj.getKey()){
                dmmap.remove(d);
                break;
            }
        }
        return dmmap;
    }
    public HashMap<Integer,Departmentmodel> Update (HashMap<Integer,Departmentmodel> dmmap) {
        //Enter DepartMent Id

        //if id exist in map or array list then Update.  ->
        //else id not found

        //return dmodel
        System.out.println("Enter the DepartmentId: ");
        int a = sc.nextInt();
        for (Map.Entry<Integer,Departmentmodel> obj :dmmap.entrySet()){
            if (a==obj.getValue().getId()){
                System.out.println("What do you want change in department: ");
                System.out.println("1)DepartmentName\n2)DepartmentDescription");
                System.out.println("Enter your choice: ");
                int update = sc.nextInt();
                if (update==1){
                    System.out.println("Enter the new department name: ");
                    String departmentName = sc.next();
                    obj.getValue().setDepartmentName(departmentName);
                }else if (update==2){
                    System.out.println("Enter the new department description: ");
                    String departmentDesc = sc.next();
                    obj.getValue().setDepartmentDesc(departmentDesc);
                }
                break;
            }
        }
        return dmmap;
    }
}






























