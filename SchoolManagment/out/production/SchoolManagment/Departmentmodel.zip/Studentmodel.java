public class Studentmodel{
    int studentId;
    String studentName;
    int studentNumber;
    String studentAddress;
    String studentGrade;

    int departmentId;


    public Studentmodel(int studentId,String studentName, int studentNumber, String studentAddress, String studentGrade,int departmentId){
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentNumber = studentNumber;
        this.studentAddress = studentAddress;
        this.studentGrade = studentGrade;
        this.departmentId = this.departmentId;
    }
    public int getDepartmentId(){
        return departmentId;
    }
    public void setDepartmentId(int departmentId){
        this.departmentId=departmentId;
    }

    public int getStudentId(){
        return studentId;
    }
    public void setStudentId(int studentId){
        this.studentId=studentId;
    }
    public String getStudentName(){
        return studentName;
    }
    public void setStudentName(String studentName){
        this.studentName = studentName;
    }
    public int getStudentNumber(){
        return studentNumber;
    }
    public  void setStudentNumber(int studentNumber){
        this.studentNumber = studentNumber;
    }
    public String getStudentAddress(){
        return studentAddress;
    }
    public void setStudentAddress(String studentAddress){
        this.studentAddress = studentAddress;
    }
    public String getStudentGrade(){
        return studentGrade;
    }
    public void setStudentGrade(String studentGrade){
        this.studentGrade = studentGrade;
    }
}
