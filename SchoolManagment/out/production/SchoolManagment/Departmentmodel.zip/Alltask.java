import java.util.HashMap;
import java.util.Scanner;

public class Alltask {
    int a;
    public void run(HashMap<Integer,Departmentmodel>dmmap,HashMap<Integer,Studentmodel>smmap){
        Scanner sc = new Scanner(System.in);
        System.out.println("-----------College Details-----------");
        System.out.println("1)Department");
        System.out.println("2)StudentDetails");
        System.out.println("3)Exit");
        System.out.println("Select the number: ");
        a = sc.nextInt();

        switch (a){
            case 1:
                Department department = new Department();
                department.method1(dmmap,smmap);
                run(dmmap,smmap);
                break;
            case 2:
                Student student = new Student();
                student.method2(dmmap,smmap);
                run(dmmap,smmap);
            default:
                break;
        }
    }
}
