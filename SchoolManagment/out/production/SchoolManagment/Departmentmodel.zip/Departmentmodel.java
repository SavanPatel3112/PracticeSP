public class Departmentmodel{
    int departmentId;
    String departmentName;
    String departmentDesc;
    public Departmentmodel(int b, int departmentId,String departmentName, String departmentDesc){
        //super();
        this.departmentId = departmentId;
        this.departmentName = departmentName;
        this.departmentDesc = departmentDesc;

    }

    public Departmentmodel() {

    }
    public int getId(){
        return departmentId;
    }
    public void setId(int departmentId){
        this.departmentId = departmentId;
    }
    public String getDepartmentName(){
        return departmentName;
    }
    public void setDepartmentName(String departmentName){
        this.departmentName = departmentName;
    }
    public String getDepartmentDesc(){
        return departmentDesc;
    }
    public void setDepartmentDesc(String departmentDesc){
        this.departmentDesc = departmentDesc;
    }


}












